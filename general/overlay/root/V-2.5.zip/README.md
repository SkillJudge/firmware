# GK7205 Encoder Shell Package

Expected fixed files in the delivery package:

- `install.sh`
- `encoder_main.sh`
- `app_service.sh`
- `feature_engine.sh`
- `protocol.sh`
- `mqtt.sh`
- `state.sh`
- `runtime.sh`
- `common.sh`
- `config.sh`
- `config_page.sh`
- `device_id.sh`
- `delete_all.sh`
- `README.md`

Runtime-generated directories that do not need to stay in the source package:

- `runtime/`
- `media/`

Notes:

- `runtime/` stores logs, pid files, state files, and temp files.
- `media/` stores local capture and audio cache files.
- Both directories are recreated automatically when the scripts start.
- The installer restores `/etc/majestic.yaml` from `/etc/majestic.yaml.bak` first, and falls back to `/etc/majestic.yaml.encoder.bak` if needed. The backup file is kept in place.
- Runtime push/record control now updates Majestic fields with `cli -s` instead of rewriting the whole YAML file.
- `DEVICE_ID` prefers the global process environment variable `ENCODER_DEVICE_ID`. If it is missing, scripts fall back to `DEVICE_ID_DEFAULT` in `config.sh` for local testing.
- The default media profile enables dual streams: `video0` is `1920x1080` at `10fps` for recording, `video1` is `640x360` at `15fps` for SRS pushing. Recording keeps `records.substream=false`; pushing uses `outgoing.substream=true` and the stream name `stream_${DEVICE_ID}`.
- Recording uploads use the FTP `upload/` root directory by default. Stop-stream, stop-record, and reset all disable `outgoing`, stop both `video0` and `video1`, and then reload Majestic.
- Verbose command, MQTT payload, and heartbeat logs are disabled by default. Set `LOG_VERBOSE`, `CONFIG_COMMAND_VERBOSE`, `MQTT_PAYLOAD_VERBOSE`, or `HEARTBEAT_LOG_VERBOSE` to `true` when deeper troubleshooting is needed.

Device id setup:

```sh
# The encoder scripts only read the global process environment.
# Another provisioning process must export it before encoder_main.sh starts.
export ENCODER_DEVICE_ID=ENC_20260420_001
sh /root/encoder/device_id.sh check
```

For login shells, the board provisioning process can place the export in a global shell profile such as `/etc/profile`.
For boot services, export `ENCODER_DEVICE_ID` in the init script before starting `encoder_main.sh`; the variable must be inherited by the encoder process.
