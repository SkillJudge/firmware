# GK7205 Encoder Shell Package

Expected fixed files in the delivery package:

- `install.sh`
- `encoder_main.sh`
- `app_service.sh`
- `battery.sh`
- `voice.sh`
- `feature_engine.sh`
- `protocol.sh`
- `mqtt.sh`
- `state.sh`
- `runtime.sh`
- `common.sh`
- `config.sh`
- `config_page.sh`
- `device_id.sh`
- `delete_all.sh`
- `README.md`

Runtime-generated directories that do not need to stay in the source package:

- `runtime/`
- `media/`

Notes:

- `runtime/` stores logs, pid files, state files, and temp files.
- `media/` stores local capture and audio cache files.
- Both directories are recreated automatically when the scripts start.
- The installer restores `/etc/majestic.yaml` from `/etc/majestic.yaml.bak` first, and falls back to `/etc/majestic.yaml.encoder.bak` if needed. The backup file is kept in place.
- Runtime push/record control updates Majestic fields with `yaml-cli -i /etc/majestic.yaml -s` instead of rewriting the whole YAML file.
- `DEVICE_ID` prefers the global process environment variable `ENCODER_DEVICE_ID`. If it is missing, scripts fall back to `DEVICE_ID_DEFAULT` in `config.sh` for local testing.
- The default media profile enables dual streams: `video0` is `1920x1080` at `10fps` for recording, `video1` is `640x360` at `15fps` for SRS pushing. Recording keeps `records.substream=false`; pushing uses `outgoing.substream=true` and the stream name `stream_${DEVICE_ID}`.
- Recording uploads use the FTP `upload/` root directory by default. Stop-stream, stop-record, and reset all disable `outgoing`, stop both `video0` and `video1`, and then reload Majestic.
- Verbose command, MQTT payload, and heartbeat logs are disabled by default. Set `LOG_VERBOSE`, `CONFIG_COMMAND_VERBOSE`, `MQTT_PAYLOAD_VERBOSE`, or `HEARTBEAT_LOG_VERBOSE` to `true` when deeper troubleshooting is needed.
- V-2.6.1 refreshes the heartbeat `battery` value from the coulomb-counter SOC register before each publish. The default hardware path is I2C bus `1`, address `0x36`, register `0x04`.
- If an I2C battery read fails, the heartbeat remains available and publishes the last valid battery value stored in `runtime/state/battery`.
- V-2.6.2 fixes Majestic runtime configuration writes on OpenIPC boards where `cli` is an `ipctool` alias. Using `yaml-cli` prevents sensor-name output such as `imx347_i2c` and applies the requested stream and recording values.
- V-2.6.3 handles `task/prepare_desk_recognition_voice/prepareDeskRecognitionVoice` by playing `/mnt/mmcblk0p1/desk_8k.pcm` five times in a background worker. `voice.sh` temporarily enables Majestic audio output, restores it to `false` on exit, and keeps the inter-play gap configurable in that script.
- V-2.6.4 refreshes heartbeat `is_charging` from the coulomb-counter CRATE register `0x16`. Positive rates above the configured threshold publish `true`, negative rates below the configured threshold publish `false`, and values near zero keep the previous state to avoid toggling at full charge.

Device id setup:

```sh
# The encoder scripts only read the global process environment.
# Another provisioning process must export it before encoder_main.sh starts.
export ENCODER_DEVICE_ID=ENC_20260420_001
sh /root/encoder/device_id.sh check
```

For login shells, the board provisioning process can place the export in a global shell profile such as `/etc/profile`.
For boot services, export `ENCODER_DEVICE_ID` in the init script before starting `encoder_main.sh`; the variable must be inherited by the encoder process.
